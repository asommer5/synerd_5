from django.db import models

class UserInfo(models.Model):
    username = models.CharField(max_length=20, default="")
    first_name = models.CharField(max_length=20, default="")
    middlename = models.CharField(max_length=20, default="")
    lastname = models.CharField(max_length=20, default="")
    email = models.CharField(max_length=20, default="")
    address1 = models.CharField(max_length=20, default="")
    address2 = models.CharField(max_length=20, default="")
    city = models.CharField(max_length=20, default="")
    state = models.CharField(max_length=20, default="")
    zipcode = models.CharField(max_length=20, default="")
    employer_name = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.username

class SubscriptionType(models.Model):
    subscriptiontypecode = models.CharField(max_length=20, default="")
    subscriptiontypename = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.subscrtiptiontypecode

class Service(models.Model):
    servicecode = models.CharField(max_length=20, default="")
    servicename = models.CharField(max_length=20, default="")
    description = models.CharField(max_length=20, default="")
    premium = models.CharField(max_length=20, default="")
    allocation = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.servicecode
    
class Subscriber(models.Model):
    subscriberID = models.CharField(max_length=20, default="") 
    username = models.ForeignKey(UserInfo, on_delete=models.CASCADE)
    subscriptiontypecode = models.ForeignKey(SubscriptionType, on_delete=models.CASCADE)
    servicecode = models.ForeignKey(Service, on_delete=models.CASCADE)
    requestdate = models.CharField(max_length=20, default="")
    startdate = models.CharField(max_length=20, default="")
    enddate = models.CharField(max_length=20, default="")
    motifofcancellation = models.CharField(max_length=20, default="")
    beneficiaryID = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.subscriberID

class TransferredSubscription(models.Model):
    transferID = models.CharField(max_length=20, default="")
    transfer_from = models.CharField(max_length=20, default="")
    transfer_to = models.CharField(max_length=20, default="")
    request_date = models.CharField(max_length=20, default="")
    transfer_date = models.CharField(max_length=20, default="")
    subscriberID = models.ForeignKey(Subscriber, on_delete=models.CASCADE)

    def __str__(self):
        return self.transferID

class Office(models.Model):
    officecode = models.CharField(max_length=20, default="")
    officename = models.CharField(max_length=20, default="")
    attribution = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.officecode

class Officer(models.Model):
    officecode = models.ForeignKey(Office, on_delete=models.CASCADE)
    subscriberID = models.ForeignKey(Subscriber, on_delete=models.CASCADE)
    startdate = models.CharField(max_length=20, default="")
    enddate = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.officecode

class Organization(models.Model):
    organization_code = models.CharField(max_length=20, default="")
    organization_name = models.CharField(max_length=20, default="")
    description = models.CharField(max_length=20, default="")
    date_joined = models.CharField(max_length=20, default="")
    address1 = models.CharField(max_length=20, default="")
    address2 = models.CharField(max_length=20, default="")
    city = models.CharField(max_length=20, default="")
    state = models.CharField(max_length=20, default="")
    zipcode = models.CharField(max_length=20, default="")
    phone_number = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.organization_code

class OrganizationMember(models.Model):
    organization_code = models.ForeignKey(Organization, on_delete=models.CASCADE)
    subscriberID = models.ForeignKey(Subscriber, on_delete=models.CASCADE)
    startdate = models.CharField(max_length=20, default="")
    enddate = models.CharField(max_length=20, default="")
    nativecountry = models.CharField(max_length=20, default="")
    citizenship = models.CharField(max_length=20, default="")
    isdelegate = models.CharField(max_length=20, default="")

    def __str__(self):
        return self.organization_code
